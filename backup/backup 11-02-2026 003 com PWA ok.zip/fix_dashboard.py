import os

file_path = r"c:\Users\Segurança\Documents\Avarias_Projeto\templates\app_avarias\dashboard.html"

content = """{% extends 'base.html' %}
{% load humanize %}

{% block title %}Painel de Controle | Gestão de Avarias{% endblock %}

{% block content %}
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Painel de Controle</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <form method="get" class="d-flex gap-2">
            <select name="month" class="form-select form-select-sm">
                {% for opt in month_options %}
                <option value="{{ opt.value }}" {% if opt.selected %}selected{% endif %}>{{ opt.value }}</option>
                {% endfor %}
            </select>
            <select name="year" class="form-select form-select-sm">
                {% for opt in year_options %}
                <option value="{{ opt.value }}" {% if opt.selected %}selected{% endif %}>{{ opt.value }}</option>
                {% endfor %}
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Filtrar</button>
            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">Exportar
                PDF</button>
        </form>
    </div>
</div>

<!-- KPI Cards Row 1: Counts -->
<div class="row g-4 mb-4">
    <div class="col-md-4 col-xl-4">
        <a href="{% url 'avaria_list' %}?status=EM_ABERTO" class="text-decoration-none">
            <div class="card bg-primary text-white h-100 shadow-sm transition-hover">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1 small opacity-75">Avarias em Aberto</h6>
                            <h2 class="mb-0 display-6 fw-bold">{{ count_open }}</h2>
                        </div>
                        <div class="fs-1 opacity-50"><i class="bi bi-exclamation-triangle"></i></div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4 col-xl-4">
        <a href="{% url 'avaria_list' %}?status=AGUARDANDO_DEVOLUCAO" class="text-decoration-none">
            <div class="card bg-warning text-dark h-100 shadow-sm transition-hover">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1 small opacity-75">Aguardando Devolução</h6>
                            <h2 class="mb-0 display-6 fw-bold">{{ count_ready_return }}</h2>
                        </div>
                        <div class="fs-1 opacity-50"><i class="bi bi-arrow-return-left"></i></div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4 col-xl-4">
        <div class="card bg-success text-white h-100 shadow-sm">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1 small opacity-75">Devoluções (Mês Atual)</h6>
                        <h2 class="mb-0 display-6 fw-bold">{{ count_monthly_returns }}</h2>
                    </div>
                    <div class="fs-1 opacity-50"><i class="bi bi-calendar-check"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- KPI Cards Row 2: Values -->
<div class="row g-4 mb-4">
    <div class="col-md-3 col-xl-3">
        <div class="card border-0 shadow-sm h-100 border-start border-4 border-primary">
            <div class="card-body">
                <small class="text-muted text-uppercase fw-bold">Valor em Aberto</small>
                <div class="fs-4 fw-bold text-primary">R$ {{ val_open|intcomma|default:"0,00" }}</div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xl-3">
        <div class="card border-0 shadow-sm h-100 border-start border-4 border-danger">
            <div class="card-body">
                <small class="text-muted text-uppercase fw-bold">Valor Devolvido</small>
                <div class="fs-4 fw-bold text-danger">R$ {{ val_returned|intcomma|default:"0,00" }}</div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xl-3">
        <div class="card border-0 shadow-sm h-100 border-start border-4 border-success">
            <div class="card-body">
                <small class="text-muted text-uppercase fw-bold">Valor Aceito (Absorvido)</small>
                <div class="fs-4 fw-bold text-success">R$ {{ val_accepted|intcomma|default:"0,00" }}</div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xl-3">
        <div class="card border-0 shadow-sm h-100 border-start border-4 border-info">
            <div class="card-body">
                <small class="text-muted text-uppercase fw-bold">Taxa de Aceite</small>
                <div class="fs-4 fw-bold text-info">{{ acceptance_rate }}%</div>
                <small class="text-muted" style="font-size: 0.75rem;">(Aceitas / Total Finalizadas)</small>
            </div>
        </div>
    </div>
</div>


<!-- FINANCIAL LISTS ROW -->
<div class="row g-4 mb-4">
    <!-- Last 12 Months -->
    <div class="col-lg-6">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white fw-bold">
                <i class="bi bi-calendar-event"></i> Prejuízos - Últimos 12 Meses
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-hover mb-0 text-center">
                    <thead class="table-light">
                        <tr>
                            <th>Mês</th>
                            <th class="text-danger">Cliente</th>
                            <th class="text-warning">Parceiro</th>
                            <th class="text-danger fw-bold">Transbirday</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for item in financial_12m %}
                        <tr>
                            <td>{{ item.month|date:"M/Y"|upper }}</td>
                            <td>R$ {{ item.total_cliente|default:0|floatformat:2|intcomma }}</td>
                            <td>R$ {{ item.total_terceiro|default:0|floatformat:2|intcomma }}</td>
                            <td class="fw-bold text-danger">R$ {{ item.total_transbirday|default:0|floatformat:2|intcomma }}</td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="4" class="text-muted">Sem dados recentes.</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Last 5 Years -->
    <div class="col-lg-6">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white fw-bold">
                <i class="bi bi-calendar-range"></i> Prejuízos - Últimos 5 Anos
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-hover mb-0 text-center">
                    <thead class="table-light">
                        <tr>
                            <th>Ano</th>
                            <th class="text-danger">Cliente</th>
                            <th class="text-warning">Parceiro</th>
                            <th class="text-danger fw-bold">Transbirday</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for item in financial_5y %}
                        <tr>
                            <td class="fw-bold">{{ item.year }}</td>
                            <td>R$ {{ item.total_cliente|default:0|floatformat:2|intcomma }}</td>
                            <td>R$ {{ item.total_terceiro|default:0|floatformat:2|intcomma }}</td>
                            <td class="fw-bold text-danger">R$ {{ item.total_transbirday|default:0|floatformat:2|intcomma }}</td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="4" class="text-muted">Sem dados históricos.</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row 1: Main Evolution -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header fw-bold bg-white">
                <i class="bi bi-graph-up"></i> Evolução Histórica de Avarias
            </div>
            <div class="card-body">
                <canvas id="evolutionChart" height="60"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row 2: Returns Evolution -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header fw-bold bg-white text-danger">
                <i class="bi bi-arrow-return-left"></i> Evolução Histórica de Devoluções
            </div>
            <div class="card-body">
                <canvas id="evolutionReturnsChart" height="60"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row 3: Accepted Evolution -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header fw-bold bg-white text-success">
                <i class="bi bi-check-circle"></i> Evolução Histórica de Aceitação
            </div>
            <div class="card-body">
                <canvas id="evolutionAcceptedChart" height="60"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Heatmap Map Row -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header fw-bold bg-white">
                <i class="bi bi-geo-alt-fill"></i> Mapa de Calor de Avarias por Estado
            </div>
            <div class="card-body">
                <div class="row">
                    <!-- Map Column -->
                    <div class="col-lg-8 border-end">
                        <div id="brazil-map" style="height: 500px; min-width: 310px; margin: 0 auto"></div>
                    </div>
                    <!-- List Column -->
                    <div class="col-lg-4">
                        <h6 class="text-muted text-uppercase small fw-bold mb-3 border-bottom pb-2">Ocorrências por
                            Estado</h6>
                        <div style="max-height: 480px; overflow-y: auto;">
                            <table class="table table-sm table-hover align-middle">
                                <thead class="table-light sticky-top">
                                    <tr>
                                        <th>Estado</th>
                                        <th class="text-end">Qtd.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for item in heatmap_list %}
                                    <tr>
                                        <td>
                                            <span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-10 me-2">{{ item.state }}</span>
                                        </td>
                                        <td class="text-end fw-bold">{{ item.count }}</td>
                                    </tr>
                                    {% empty %}
                                    <tr>
                                        <td colspan="2" class="text-center text-muted small py-3">Sem dados registrados.
                                        </td>
                                    </tr>
                                    {% endfor %}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Lists Row -->
<div class="row g-4 mb-4">
    <div class="col-lg-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-light fw-bold text-center">Produtos: Mais Avariados (Total)</div>
            <ul class="list-group list-group-flush small">
                {% for p in top_products_total %}
                <li class="list-group-item d-flex justify-content-between">
                    <span>{{ p.produto__nome }}</span>
                    <span class="fw-bold">{{ p.total }}</span>
                </li>
                {% endfor %}
            </ul>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-light fw-bold text-center">Produtos: Mais Devolvidos</div>
            <ul class="list-group list-group-flush small">
                {% for p in top_products_returned %}
                <li class="list-group-item d-flex justify-content-between">
                    <span>{{ p.produto__nome }}</span>
                    <span class="fw-bold text-danger">{{ p.total }}</span>
                </li>
                {% endfor %}
            </ul>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-light fw-bold text-center">Produtos: Mais Aceitos/Recebidos</div>
            <ul class="list-group list-group-flush small">
                {% for p in top_products_accepted %}
                <li class="list-group-item d-flex justify-content-between">
                    <span>{{ p.produto__nome }}</span>
                    <span class="fw-bold text-success">{{ p.total }}</span>
                </li>
                {% endfor %}
            </ul>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Top Drivers -->
    <div class="col-lg-6">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white font-weight-bold">
                <i class="bi bi-steering-wheel"></i> Motoristas com Mais Ocorrências
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for d in top_drivers %}
                        <tr>
                            <td>{{ d.motorista__nome }}</td>
                            <td>{{ d.motorista__cpf }}</td>
                            <td class="text-end fw-bold">{{ d.total }}</td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="3" class="text-center text-muted">Sem dados.</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- SLAs -->
    <div class="col-lg-6">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white font-weight-bold">
                <i class="bi bi-stopwatch"></i> SLAs e Tempos de Resposta
            </div>
            <div class="card-body">

                <h6 class="text-primary small text-uppercase fw-bold mb-3">Tempo de Definição (Aberto -> Decisão)</h6>
                <div class="row text-center mb-4">
                    <div class="col-4 border-end">
                        <small class="text-muted d-block">Mínimo</small>
                        <span class="fw-bold">{{ sla_decision.min_time|default:"-" }}</span>
                    </div>
                    <div class="col-4 border-end">
                        <small class="text-muted d-block">Médio</small>
                        <span class="fw-bold text-primary">{{ sla_decision.avg_time|default:"-" }}</span>
                    </div>
                    <div class="col-4">
                        <small class="text-muted d-block">Máximo</small>
                        <span class="fw-bold">{{ sla_decision.max_time|default:"-" }}</span>
                    </div>
                </div>

                <h6 class="text-info small text-uppercase fw-bold mb-3">Tempo de Saída (Decisão -> Em Rota)</h6>
                <div class="row text-center mb-4">
                    <div class="col-4 border-end">
                        <small class="text-muted d-block">Mínimo</small>
                        <span class="fw-bold">{{ sla_waiting_return.min_time|default:"-" }}</span>
                    </div>
                    <div class="col-4 border-end">
                        <small class="text-muted d-block">Médio</small>
                        <span class="fw-bold text-info">{{ sla_waiting_return.avg_time|default:"-" }}</span>
                    </div>
                    <div class="col-4">
                        <small class="text-muted d-block">Máximo</small>
                        <span class="fw-bold">{{ sla_waiting_return.max_time|default:"-" }}</span>
                    </div>
                </div>

                <h6 class="text-success small text-uppercase fw-bold mb-3">Tempo de Transporte (Rota -> Finalizado)</h6>
                <div class="row text-center">
                    <div class="col-4 border-end">
                        <small class="text-muted d-block">Mínimo</small>
                        <span class="fw-bold">{{ sla_transport.min_time|default:"-" }}</span>
                    </div>
                    <div class="col-4 border-end">
                        <small class="text-muted d-block">Médio</small>
                        <span class="fw-bold text-success">{{ sla_transport.avg_time|default:"-" }}</span>
                    </div>
                    <div class="col-4">
                        <small class="text-muted d-block">Máximo</small>
                        <span class="fw-bold">{{ sla_transport.max_time|default:"-" }}</span>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block extra_js %}
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Highmaps -->
<script src="https://code.highcharts.com/maps/highmaps.js"></script>
<script src="https://code.highcharts.com/mapdata/countries/br/br-all.js"></script>

<script>
    // --- MAP ---
    try {
        const mapData = {{ heatmap_data|safe }};
        console.log("Map Data:", mapData);

        if (mapData && mapData.length > 0) {
            Highcharts.mapChart('brazil-map', {
                chart: { map: 'countries/br/br-all' },
                title: { text: '' },
                subtitle: { text: 'Fonte: Registros de Avarias por Local de Atuação' },
                mapNavigation: { enabled: true, buttonOptions: { verticalAlign: 'bottom' } },
                colorAxis: { min: 0, minColor: '#ffebd2', maxColor: '#e65100', labels: { format: '{value}' } },
                series: [{
                    data: mapData,
                    keys: ['hc-key', 'value'],
                    joinBy: 'hc-key',
                    name: 'Avarias',
                    nullColor: '#d3d3d3',
                    states: { hover: { color: '#BADA55' } },
                    dataLabels: { enabled: true, format: '{point.name}' },
                    tooltip: { pointFormat: '{point.name}: {point.value}' }
                }]
            });
        }
    } catch (e) { console.error("Error initializing map:", e); }

    // --- CHARTS ---
    try {
        const formatDate = (dateString) => {
            if (!dateString) return '';
            const [y, m, d] = dateString.split('-');
            const date = new Date(y, m - 1, d);
            return date.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
        };

        // Evolution
        const evolutionData = {{ evolution_data|safe }};
        if (document.getElementById('evolutionChart')) {
            new Chart(document.getElementById('evolutionChart'), {
                type: 'line',
                data: {
                    labels: evolutionData.map(d => formatDate(d.month)),
                    datasets: [{
                        label: 'Avarias Registradas',
                        data: evolutionData.map(d => d.total_created),
                        borderColor: '#0d6efd',
                        backgroundColor: 'rgba(13, 110, 253, 0.1)',
                        tension: 0.3,
                        fill: true
                    }]
                },
                options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
            });
        }

        // Returns
        const returnsData = {{ evolution_returns|safe }};
        if (document.getElementById('evolutionReturnsChart')) {
            new Chart(document.getElementById('evolutionReturnsChart'), {
                type: 'line',
                data: {
                    labels: returnsData.map(d => formatDate(d.month)),
                    datasets: [{
                        label: 'Devoluções Concluídas',
                        data: returnsData.map(d => d.total),
                        borderColor: '#dc3545',
                        backgroundColor: 'rgba(220, 53, 69, 0.1)',
                        tension: 0.3,
                        fill: true
                    }]
                },
                options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
            });
        }

        // Accepted
        const acceptedData = {{ evolution_accepted|safe }};
        if (document.getElementById('evolutionAcceptedChart')) {
            new Chart(document.getElementById('evolutionAcceptedChart'), {
                type: 'line',
                data: {
                    labels: acceptedData.map(d => formatDate(d.month)),
                    datasets: [{
                        label: 'Aceites',
                        data: acceptedData.map(d => d.total),
                        borderColor: '#198754',
                        backgroundColor: 'rgba(25, 135, 84, 0.1)',
                        tension: 0.3,
                        fill: true
                    }]
                },
                options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
            });
        }
    } catch (e) { console.error("Error initializing charts:", e); }
</script>
{% endblock %}"""

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)

print(f"File {file_path} successfully rewritten.")
