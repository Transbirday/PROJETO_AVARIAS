
from django import forms
from .models import Avaria, AvariaFoto, Veiculo

class MultipleFileInput(forms.FileInput):
    allow_multiple_selected = True

class AvariaForm(forms.ModelForm):
    class Meta:
        model = Avaria
        fields = ['cliente', 'nota_fiscal', 'produto', 'quantidade', 'motorista', 'veiculo']
        widgets = {
            'cliente': forms.Select(attrs={'class': 'form-select select2'}),
            'nota_fiscal': forms.TextInput(attrs={'class': 'form-control'}),
            'produto': forms.Select(attrs={'class': 'form-select select2'}),
            'quantidade': forms.NumberInput(attrs={'class': 'form-control'}),
            'motorista': forms.Select(attrs={'class': 'form-select select2'}),
            'veiculo': forms.Select(attrs={'class': 'form-select select2'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Filter main form vehicle to show only PRINCIPAL
        if 'veiculo' in self.fields:
             self.fields['veiculo'].queryset = Veiculo.objects.filter(tipo='PRINCIPAL', ativo=True)
        # Allow multiple selection for batch creation
        self.fields['produto'] = forms.ModelMultipleChoiceField(
            queryset=Produto.objects.all(), # Should filter active?
            widget=forms.SelectMultiple(attrs={'class': 'form-select select2', 'multiple': 'multiple'}),
            help_text="Selecione um ou mais produtos para criar avarias em lote."
        )
        # Just to be safe with queryset if needed (e.g. active only)
        self.fields['produto'].queryset = Produto.objects.filter(ativo=True)

class AvariaDecisaoForm(forms.Form):
    acao = forms.ChoiceField(choices=[('ACEITAR', 'Aceitar (Finalizar)'), ('DEVOLVER', 'Iniciar Devolução')], widget=forms.RadioSelect, label="Decisão")
    nf_retida_conferencia = forms.ChoiceField(
        choices=[('NAO', 'Não'), ('SIM', 'Sim')],
        widget=forms.RadioSelect(attrs={'class': 'btn-check-group'}), # Custom class for JS hook or styling
        label="A NF ficou retida na conferência?",
        initial='NAO'
    )
    horas_retencao = forms.IntegerField(
        required=False,
        label="Quantas horas de retenção?",
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 2'})
    )
    observacao = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3}), required=False, label="Observação da Decisão")

class AvariaDevolucaoForm(forms.ModelForm):
    class Meta:
        model = Avaria
        fields = ['motorista_devolucao', 'veiculo_devolucao', 'veiculo_devolucao_carreta', 'nf_devolucao']
        widgets = {
            'motorista_devolucao': forms.Select(attrs={'class': 'form-select select2'}),
            'veiculo_devolucao': forms.Select(attrs={'class': 'form-select select2'}),
            'veiculo_devolucao_carreta': forms.Select(attrs={'class': 'form-select select2'}),
            'nf_devolucao': forms.TextInput(attrs={'class': 'form-control'}),
        }
        labels = {
            'motorista_devolucao': 'MOTORISTA RETORNO',
            'veiculo_devolucao': 'VEÍCULO PRINCIPAL RETORNO (OBRIGATÓRIO)',
            'veiculo_devolucao_carreta': 'CARRETA/REBOQUE RETORNO',
            'nf_devolucao': 'NFD',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['veiculo_devolucao'].required = True
        
        # Filters for Return Flow
        if 'veiculo_devolucao' in self.fields:
            self.fields['veiculo_devolucao'].queryset = Veiculo.objects.filter(tipo='PRINCIPAL', ativo=True)
            
        if 'veiculo_devolucao_carreta' in self.fields:
            self.fields['veiculo_devolucao_carreta'].queryset = Veiculo.objects.filter(tipo='CARRETA', ativo=True)

    observacao_extra = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3}), required=False, label="OBS. SAÍDA")


class AvariaFinalizacaoDevolucaoForm(forms.Form):
    arquivo_comprovante = forms.FileField(widget=forms.ClearableFileInput(attrs={'class': 'form-control'}), required=True, label="Foto do Canhoto/Entrega (Obrigatório)")

class AvariaDefinicaoPrejuizoForm(forms.ModelForm):
    class Meta:
        model = Avaria
        fields = ['responsavel_prejuizo']
        widgets = {
            'responsavel_prejuizo': forms.Select(attrs={'class': 'form-select'}),
        }

class AvariaObservacaoForm(forms.Form):
    texto = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Adicionar nova observação...'}),
        label="Nova Observação"
    )

class AvariaFotoForm(forms.ModelForm):
    class Meta:
        model = AvariaFoto
        fields = ['arquivo']
    
    # Keeping this custom widget for multiple file handling if needed in list view or specific upload Logic
    # But sticking to standard ModelForm for consistency in other views if possible.
    # Reverting to use ModelForm structure as base.
    # The previous definition used forms.Form with custom widget.
    # Let's support both or just clean it up.
    
    # We will overwrite the widget to support multiple in the template logic or here:
    arquivo = forms.FileField(
        widget=MultipleFileInput(attrs={'class': 'form-control', 'multiple': True, 'accept': 'image/*'}),
        label="Selecionar Fotos",
        required=False
    )
