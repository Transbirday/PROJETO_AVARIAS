
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import logout
from django.utils import timezone
from django.db.models import Sum, Count, Q, F, ExpressionWrapper, DurationField, Avg, Min, Max
from .models import Avaria, AvariaFoto
from .forms import (
    AvariaForm, AvariaDecisaoForm, AvariaDevolucaoForm, AvariaObservacaoForm, 
    AvariaFotoForm, AvariaFinalizacaoDevolucaoForm, AvariaDefinicaoPrejuizoForm
)

from django.db.models.functions import TruncMonth, ExtractMonth, ExtractYear
import json
from django.core.serializers.json import DjangoJSONEncoder

@login_required
def dashboard(request):
    """
    Dashboard Home View with Advanced KPIs, Financials, Charts and SLAs
    """
    qs_all = Avaria.objects.all()

    # --- FILTER LOGIC ---
    now = timezone.now()
    month_filter = request.GET.get('month')
    year_filter = request.GET.get('year')

    try:
        current_month = int(month_filter) if month_filter else now.month
        current_year = int(year_filter) if year_filter else now.year
    except ValueError:
        current_month = now.month
        current_year = now.year

    qs_created = qs_all.filter(data_criacao__year=current_year, data_criacao__month=current_month)
    qs_finalized_in_period = qs_all.filter(status='FINALIZADA', data_finalizacao__year=current_year, data_finalizacao__month=current_month)

    # GLOBAL COUNTERS (Unfiltered)
    qs_open = qs_all.filter(status='EM_ABERTO')
    qs_waiting = qs_all.filter(status='AGUARDANDO_DEVOLUCAO')
    qs_finalized = qs_all.filter(status='FINALIZADA')
    
    count_open = qs_open.count()
    count_ready_return = qs_waiting.count()
    
    count_monthly_returns = qs_all.filter(
        tipo_finalizacao='DEVOLUCAO_CONCLUIDA',
        data_finalizacao__month=current_month,
        data_finalizacao__year=current_year
    ).count()
    
    # Financials (Sum of valor_nf)
    from decimal import Decimal

    val_open = qs_open.aggregate(total=Sum('valor_nf'))['total'] or 0
    if isinstance(val_open, (int, float, Decimal)):
        val_open = Decimal(str(val_open)).quantize(Decimal('0.01'))
    
    val_returned = qs_finalized.filter(tipo_finalizacao='DEVOLUCAO_CONCLUIDA').aggregate(total=Sum('valor_nf'))['total'] or 0
    if isinstance(val_returned, (int, float, Decimal)):
        val_returned = Decimal(str(val_returned)).quantize(Decimal('0.01'))
    
    val_accepted = qs_finalized.filter(tipo_finalizacao='ACEITE').aggregate(total=Sum('valor_nf'))['total'] or 0
    if isinstance(val_accepted, (int, float, Decimal)):
        val_accepted = Decimal(str(val_accepted)).quantize(Decimal('0.01'))
    
    total_finished_decided = qs_finalized.filter(tipo_finalizacao__in=['ACEITE', 'DEVOLUCAO_CONCLUIDA']).count()
    count_accepted = qs_finalized.filter(tipo_finalizacao='ACEITE').count()
    
    acceptance_rate = 0
    if total_finished_decided > 0:
        acceptance_rate = (count_accepted / total_finished_decided) * 100

    # 2. CHARTS DATA
    
    # A. Monthly Evolution (Created vs Finalized)
    evolution_data = (
        qs_all
        .annotate(month=TruncMonth('data_criacao'))
        .values('month')
        .annotate(total_created=Count('id'))
        .order_by('month')
    )
    evolution_data = list(evolution_data)
    for d in evolution_data:
        if d['month']:
            d['month'] = d['month'].strftime('%Y-%m-%d')
    
    # Evolution: Returns (By Finalization Date)
    evolution_returns = (
        qs_finalized
        .filter(tipo_finalizacao='DEVOLUCAO_CONCLUIDA')
        .annotate(month=TruncMonth('data_finalizacao'))
        .values('month')
        .annotate(total=Count('id'))
        .order_by('month')
    )
    evolution_returns = list(evolution_returns)
    for d in evolution_returns:
        if d['month']:
            d['month'] = d['month'].strftime('%Y-%m-%d')

    # Evolution: Accepted (By Finalization Date)
    evolution_accepted = (
        qs_finalized
        .filter(tipo_finalizacao='ACEITE')
        .annotate(month=TruncMonth('data_finalizacao'))
        .values('month')
        .annotate(total=Count('id'))
        .order_by('month')
    )
    evolution_accepted = list(evolution_accepted)
    for d in evolution_accepted:
        if d['month']:
            d['month'] = d['month'].strftime('%Y-%m-%d')

    # B. Client Acceptance vs Rejection (Global)
    client_stats = (
        qs_finalized
        .values('cliente__razao_social')
        .annotate(
            accepted=Count('id', filter=Q(tipo_finalizacao='ACEITE')),
            returned=Count('id', filter=Q(tipo_finalizacao='DEVOLUCAO_CONCLUIDA'))
        )
        .order_by('-accepted')[:10]
    )
    
    # D. Heatmap (Global)
    raw_locations = list(qs_all
        .exclude(local_atuacao__isnull=True)
        .values('local_atuacao')
        .annotate(total=Count('id')))
        
    # Map to BR states
    import re
    state_counts = {}
    valid_states = [
        'ac', 'al', 'ap', 'am', 'ba', 'ce', 'df', 'es', 'go', 'ma', 'mt', 'ms', 'mg', 
        'pa', 'pb', 'pr', 'pe', 'pi', 'rj', 'rn', 'rs', 'ro', 'rr', 'sc', 'sp', 'se', 'to'
    ]
    
    for item in raw_locations:
        loc_str = (item['local_atuacao'] or "").lower()
        cnt = item['total']
        match = re.search(r'\b(' + '|'.join(valid_states) + r')\b', loc_str)
        if match:
            state_code = match.group(1)
            key = f"br-{state_code}"
            state_counts[key] = state_counts.get(key, 0) + cnt
    
    heatmap_data = [[k, v] for k, v in state_counts.items()]
    heatmap_list = []
    
    STATE_MAP = {
        'ac': 'Acre', 'al': 'Alagoas', 'ap': 'Amapá', 'am': 'Amazonas', 'ba': 'Bahia',
        'ce': 'Ceará', 'df': 'Distrito Federal', 'es': 'Espírito Santo', 'go': 'Goiás',
        'ma': 'Maranhão', 'mt': 'Mato Grosso', 'ms': 'Mato Grosso do Sul', 'mg': 'Minas Gerais',
        'pa': 'Pará', 'pb': 'Paraíba', 'pr': 'Paraná', 'pe': 'Pernambuco', 'pi': 'Piauí',
        'rj': 'Rio de Janeiro', 'rn': 'Rio Grande do Norte', 'rs': 'Rio Grande do Sul',
        'ro': 'Rondônia', 'rr': 'Roraima', 'sc': 'Santa Catarina', 'sp': 'São Paulo',
        'se': 'Sergipe', 'to': 'Tocantins'
    }

    for k, v in state_counts.items():
        state_code = k.replace('br-', '')
        state_name = STATE_MAP.get(state_code, state_code.upper())
        heatmap_list.append({'state': state_name, 'count': v})
    
    heatmap_list.sort(key=lambda x: x['count'], reverse=True)

    # 3. TOP OFENDERS
    top_drivers = (
        qs_all
        .values('motorista__nome', 'motorista__cpf')
        .annotate(total=Count('id'))
        .order_by('-total')[:5]
    )
    
    top_products_total = (
        qs_all
        .values('produto__nome')
        .annotate(total=Count('id'))
        .order_by('-total')[:5]
    )
    
    top_products_returned = (
        qs_finalized
        .filter(tipo_finalizacao='DEVOLUCAO_CONCLUIDA')
        .values('produto__nome')
        .annotate(total=Count('id'))
        .order_by('-total')[:5]
    )
    
    top_products_accepted = (
        qs_finalized
        .filter(tipo_finalizacao='ACEITE')
        .values('produto__nome')
        .annotate(total=Count('id'))
        .order_by('-total')[:5]
    )

    # 4. SLAs
    def calc_sla(queryset, start_field, end_field):
        qs = queryset.filter(**{f"{start_field}__isnull": False, f"{end_field}__isnull": False})
        if not qs.exists():
            return {'min_time': None, 'avg_time': None, 'max_time': None}
        stats = qs.aggregate(
            min_time=Min(ExpressionWrapper(F(end_field) - F(start_field), output_field=DurationField())),
            avg_time=Avg(ExpressionWrapper(F(end_field) - F(start_field), output_field=DurationField())),
            max_time=Max(ExpressionWrapper(F(end_field) - F(start_field), output_field=DurationField()))
        )
        return stats

    def format_duration(value):
        if not value: return "-"
        days = value.days
        seconds = value.seconds
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{days} Dias e {hours:02}:{minutes:02} Horas"

    def format_sla_dict(stats):
        return {
            'min_time': format_duration(stats['min_time']),
            'avg_time': format_duration(stats['avg_time']),
            'max_time': format_duration(stats['max_time'])
        }

    sla_decision = format_sla_dict(calc_sla(qs_all, 'data_criacao', 'data_decisao'))
    sla_waiting_return = format_sla_dict(calc_sla(qs_all, 'data_decisao', 'data_inicio_devolucao'))
    sla_transport = format_sla_dict(calc_sla(qs_finalized.filter(tipo_finalizacao='DEVOLUCAO_CONCLUIDA'), 'data_inicio_devolucao', 'data_finalizacao'))
    
    # -------------------------------------------------------------
    # NEW LISTS: Monthly (12 months) and Annual (5 years) Financials
    # -------------------------------------------------------------
    # Helper to get financial breakdown
    def get_financial_history(trunc_func, limit):
         history = (qs_finalized
            .annotate(period=trunc_func('data_finalizacao'))
            .values('period')
            .annotate(
                val_devolvido=Sum('valor_nf', filter=Q(tipo_finalizacao='DEVOLUCAO_CONCLUIDA')),
                val_aceitas=Sum('valor_nf', filter=Q(tipo_finalizacao='ACEITE')),
                val_prejuizo=Sum('valor_nf', filter=Q(responsavel_prejuizo='TRANSBIRDAY'))
            )
            .order_by('-period')[:limit]
         )
         return list(history)
         
    history_monthly = get_financial_history(TruncMonth, 12)
    history_yearly = get_financial_history(ExtractYear, 5)

    # C. Financial Breakdown Lists (Monthly & Yearly)
    
    # 1. Last 12 Months
    from datetime import timedelta
    last_12_months = now - timedelta(days=365)
    financial_12m = (
        qs_finalized
        .filter(data_finalizacao__gte=last_12_months)
        .annotate(month=TruncMonth('data_finalizacao'))
        .values('month')
        .annotate(
            total_cliente=Sum('valor_nf', filter=Q(responsavel_prejuizo='CLIENTE')),
            total_transbirday=Sum('valor_nf', filter=Q(responsavel_prejuizo='TRANSBIRDAY')),
            total_terceiro=Sum('valor_nf', filter=Q(responsavel_prejuizo='TRANSPORTADORA_TERCEIRA')),
        )
        .order_by('-month')
    )
    
    # 2. Last 5 Years
    last_5_years = now - timedelta(days=365*5)
    financial_5y = (
        qs_finalized
        .filter(data_finalizacao__gte=last_5_years)
        .annotate(year=ExtractYear('data_finalizacao'))
        .values('year')
        .annotate(
            total_cliente=Sum('valor_nf', filter=Q(responsavel_prejuizo='CLIENTE')),
            total_transbirday=Sum('valor_nf', filter=Q(responsavel_prejuizo='TRANSBIRDAY')),
            total_terceiro=Sum('valor_nf', filter=Q(responsavel_prejuizo='TRANSPORTADORA_TERCEIRA')),
        )
        .order_by('-year')
    )

    context = {
        'count_open': count_open,
        'count_ready_return': count_ready_return,
        'count_monthly_returns': count_monthly_returns,
        'val_open': val_open,
        'val_returned': val_returned,
        'val_accepted': val_accepted,
        'acceptance_rate': round(acceptance_rate, 1),
        
        'evolution_data': json.dumps(evolution_data, cls=DjangoJSONEncoder), 
        'evolution_returns': json.dumps(evolution_returns, cls=DjangoJSONEncoder),
        'evolution_accepted': json.dumps(evolution_accepted, cls=DjangoJSONEncoder),
        'client_stats': list(client_stats),
        'heatmap_data': json.dumps(heatmap_data, cls=DjangoJSONEncoder),
        'heatmap_list': heatmap_list,
        
        'top_drivers': top_drivers,
        'top_products_total': top_products_total,
        'top_products_returned': top_products_returned,
        'top_products_accepted': top_products_accepted,
        
        'sla_decision': sla_decision,
        'sla_waiting_return': sla_waiting_return,
        'sla_transport': sla_transport,
        
        'history_monthly': history_monthly,
        'history_yearly': history_yearly,
        
        # New Financial Lists
        'financial_12m': financial_12m,
        'financial_5y': financial_5y,

        'month_options': [{'value': m, 'selected': m == current_month} for m in range(1, 13)],
        'year_options': [{'value': y, 'selected': y == current_year} for y in range(2024, 2030)],
    }
    return render(request, 'app_avarias/dashboard.html', context)

@login_required
def avaria_search(request):
    import logging
    logger = logging.getLogger(__name__)
    
    # Get Params
    q = request.GET.get('q') # Termo geral (optional)
    status = request.GET.get('status')
    data_ini = request.GET.get('data_ini')
    data_fim = request.GET.get('data_fim')
    
    # Specific Filters
    nf = request.GET.get('nf')
    nfd = request.GET.get('nfd') # NF Devolucao
    placa = request.GET.get('placa')
    cpf = request.GET.get('cpf')
    motorista = request.GET.get('motorista')
    local = request.GET.get('local')
    
    avarias = Avaria.objects.all().order_by('-data_criacao')
    
    # Generic Search
    if q:
        avarias = avarias.filter(
            Q(nota_fiscal__icontains=q) |
            Q(cliente__razao_social__icontains=q) |
            Q(produto__nome__icontains=q) |
            Q(veiculo__placa__icontains=q) |
            Q(motorista__nome__icontains=q)
        )
    
    # Specific Filters
    if status:
        avarias = avarias.filter(status=status)
    if data_ini:
        avarias = avarias.filter(data_criacao__date__gte=data_ini)
    if data_fim:
        avarias = avarias.filter(data_criacao__date__lte=data_fim)
        
    if nf:
        avarias = avarias.filter(nota_fiscal__icontains=nf)
    if nfd:
        avarias = avarias.filter(nf_devolucao__icontains=nfd)
    if placa:
        avarias = avarias.filter(
            Q(veiculo__placa__icontains=placa) | 
            Q(veiculo_carreta__placa__icontains=placa)
        )
    if cpf:
        avarias = avarias.filter(motorista__cpf__icontains=cpf)
    if motorista:
        avarias = avarias.filter(motorista__nome__icontains=motorista)
    if local:
        avarias = avarias.filter(local_atuacao__icontains=local)
        
    return render(request, 'app_avarias/avaria_search.html', {'avarias': avarias})

@login_required
def avaria_list(request):
    status_filter = request.GET.get('status', 'EM_ABERTO')
    avarias = Avaria.objects.all().prefetch_related('itens__produto').order_by('-data_criacao')
    
    if status_filter and status_filter != 'TODAS':
        avarias = avarias.filter(status=status_filter)
        
    context = {
        'avarias': avarias,
        'current_filter': status_filter
    }
    return render(request, 'app_avarias/avaria_list.html', context)

# @login_required
# def avaria_create(request):
#     # This view is deprecated in favor of Class Based View, but kept for legacy reference or fallback
#     if request.method == 'POST':
#         form = AvariaForm(request.POST)
#         if form.is_valid():
#             avaria = form.save(commit=False)
#             avaria.criado_por = request.user
#             avaria.save()
#             messages.success(request, 'Avaria registrada com sucesso!')
#             return redirect('avaria_detail', pk=avaria.pk)
#     else:
#         form = AvariaForm()
#     
#     return render(request, 'app_avarias/avaria_form.html', {'form': form, 'title': 'Nova Avaria'})

@login_required
def avaria_detail(request, pk):
    avaria = get_object_or_404(Avaria, pk=pk)
    fotos_ordenadas = avaria.fotos.select_related('criado_por').order_by('criado_por', '-data_upload')
    
    obs_form = AvariaObservacaoForm()
    
    # Forms for actions
    decisao_form = AvariaDecisaoForm()
    devolucao_form = AvariaDevolucaoForm(instance=avaria)
    photo_form = AvariaFotoForm()
    finalizacao_form = AvariaFinalizacaoDevolucaoForm() # New form
    
    if request.method == 'POST':
        if 'add_observacao' in request.POST:
            obs_form = AvariaObservacaoForm(request.POST)
            if obs_form.is_valid():
                texto = obs_form.cleaned_data['texto']
                timestamp = timezone.localtime(timezone.now()).strftime("%d/%m/%Y %H:%M")
                new_entry = f"[{timestamp} - {request.user.username}] {texto}\n"
                if avaria.observacoes:
                    avaria.observacoes += "\n" + new_entry
                else:
                    avaria.observacoes = new_entry
                avaria.save()
                messages.success(request, 'Observação adicionada.')
                return redirect('avaria_detail', pk=pk)
        
        elif 'decisao' in request.POST:
            decisao_form = AvariaDecisaoForm(request.POST)
            if decisao_form.is_valid():
                acao = decisao_form.cleaned_data['acao']
                obs_text = decisao_form.cleaned_data.get('observacao', '')
                
                # NF Retention Info
                nf_retida = decisao_form.cleaned_data.get('nf_retida_conferencia')
                horas = decisao_form.cleaned_data.get('horas_retencao')
                
                retencao_str = ""
                if nf_retida == 'SIM':
                    retencao_str = f" | [NF RETIDA NA CONFERÊNCIA: SIM ({horas}h)]"
                else:
                    retencao_str = " | [NF RETIDA NA CONFERÊNCIA: NÃO]"
                
                timestamp = timezone.localtime(timezone.now()).strftime("%d/%m/%Y %H:%M")
                new_entry = f"[{timestamp} - {request.user.username}] [DECISÃO: {acao}]{retencao_str} {obs_text}\n"

                if avaria.observacoes:
                    avaria.observacoes += "\n" + new_entry
                else:
                    avaria.observacoes = new_entry
                
                if acao == 'ACEITAR':
                    avaria.status = 'FINALIZADA'
                    avaria.tipo_finalizacao = 'ACEITE'
                    avaria.data_decisao = timezone.now()
                    avaria.data_finalizacao = timezone.now()
                    avaria.save()
                    messages.success(request, 'Avaria aceita e finalizada!')
                else: # DEVOLVER
                    avaria.status = 'AGUARDANDO_DEVOLUCAO'
                    avaria.data_decisao = timezone.now()
                    avaria.save()
                    messages.info(request, 'Avaria encaminhada para devolução. Aguardando dados de saída.')
                return redirect('avaria_detail', pk=pk)

        elif 'iniciar_devolucao' in request.POST:
            devolucao_form = AvariaDevolucaoForm(request.POST, request.FILES, instance=avaria)
            if devolucao_form.is_valid():
                avaria = devolucao_form.save(commit=False)
                
                avaria.status = 'EM_ROTA_DEVOLUCAO'
                avaria.data_inicio_devolucao = timezone.now()
                
                # History / Observation Log
                obs_text = devolucao_form.cleaned_data.get('observacao_extra') or ""
                timestamp = timezone.localtime(timezone.now()).strftime("%d/%m/%Y %H:%M")
                new_entry = f"[{timestamp} - {request.user.username}] [SAÍDA DEVOLUÇÃO] {obs_text}\n"
                
                if avaria.observacoes:
                    avaria.observacoes += "\n" + new_entry
                else:
                    avaria.observacoes = new_entry
                        
                avaria.save()
                messages.success(request, 'Devolução iniciada! Avaria em Rota.')
                return redirect('avaria_detail', pk=pk)
            else:
                 messages.error(request, 'Erro ao iniciar devolução. Verifique o formulário e a foto obrigatória.')

        elif 'finalizar_devolucao' in request.POST:
            finalizacao_form = AvariaFinalizacaoDevolucaoForm(request.POST, request.FILES)
            if finalizacao_form.is_valid():
                comprovante = finalizacao_form.cleaned_data.get('arquivo_comprovante')
                if comprovante:
                    AvariaFoto.objects.create(avaria=avaria, arquivo=comprovante, criado_por=request.user)
                
                avaria.status = 'FINALIZADA'
                avaria.tipo_finalizacao = 'DEVOLUCAO_CONCLUIDA'
                avaria.data_finalizacao = timezone.now()
                
                # History Log
                timestamp = timezone.localtime(timezone.now()).strftime("%d/%m/%Y %H:%M")
                new_entry = f"[{timestamp} - {request.user.username}] [DEVOLUÇÃO CONCLUÍDA] Processo finalizado com comprovante.\n"
                
                if avaria.observacoes:
                    avaria.observacoes += "\n" + new_entry
                else:
                    avaria.observacoes = new_entry
                    
                avaria.save()
                messages.success(request, 'Devolução concluída e finalizada!')
                return redirect('avaria_detail', pk=pk)
            else:
                messages.error(request, 'Foto do canhoto/entrega é obrigatória para finalizar.')

        elif 'upload_foto' in request.POST:
            files = request.FILES.getlist('arquivo')
            if files:
                for f in files:
                    AvariaFoto.objects.create(
                        avaria=avaria,
                        arquivo=f,
                        criado_por=request.user
                    )
                messages.success(request, f'{len(files)} foto(s) enviada(s) com sucesso!')
            else:
                messages.warning(request, 'Nenhum arquivo capturado. Tente novamente.')
            return redirect('avaria_detail', pk=pk)

    context = {
        'avaria': avaria,
        'obs_form': obs_form,
        'decisao_form': decisao_form,
        'devolucao_form': devolucao_form,
        'photo_form': photo_form,
        'fotos_ordenadas': fotos_ordenadas,
        'finalizacao_form': finalizacao_form,
    }
    return render(request, 'app_avarias/avaria_detail.html', context)

def custom_logout(request):
    logout(request)
    return redirect('login')

@login_required
def avaria_definicao_prejuizo_list(request):
    """
    List of finalized avarias (Devolucao Return) that need prejudice responsibility definition.
    """
    # Only show items that are Finalized (Returned or maybe Accepted?) and have no definition yet
    # Assuming only DEVOLUCAO_CONCLUIDA requires this step per request instructions ("Depois de finalizada (Devolução entregue)")
    qs = Avaria.objects.filter(
        status='FINALIZADA',
        tipo_finalizacao='DEVOLUCAO_CONCLUIDA',
        responsavel_prejuizo__isnull=True
    ).order_by('-data_finalizacao')
    
    if request.method == 'POST':
        avaria_pk = request.POST.get('avaria_id')
        avaria = get_object_or_404(Avaria, pk=avaria_pk)
        form = AvariaDefinicaoPrejuizoForm(request.POST, instance=avaria)
        if form.is_valid():
            # Before saving, capture the responsibility for logging
            responsavel = form.cleaned_data.get('responsavel_prejuizo')
            
            # History Log
            timestamp = timezone.localtime(timezone.now()).strftime("%d/%m/%Y %H:%M")
            
            # Detailed text construction
            detalhes_responsavel = ""
            if responsavel == 'TRANSBIRDAY':
                detalhes_responsavel = "TRANSPORTES BIRDAY COMERCIO LTDA (00.343.915/0001-08)"
            elif responsavel == 'CLIENTE':
                detalhes_responsavel = f"{avaria.cliente.razao_social} ({avaria.cliente.cnpj})"
            elif responsavel == 'TRANSPORTADORA_TERCEIRA':
                if avaria.veiculo.propriedade == 'TERCEIRO':
                    detalhes_responsavel = f"{avaria.veiculo.transportadora_nome} ({avaria.veiculo.transportadora_cnpj})"
                else:
                    # Fallback if selected transport service but it's not registered as third party (unlikely but safe)
                    detalhes_responsavel = "Transportadora Terceira (Dados não vinculados ao veículo)"
            
            new_entry = f"[{timestamp} - {request.user.username}] [DEFINIÇÃO DE PREJUÍZO] Responsável: {avaria.get_responsavel_prejuizo_display()} - {detalhes_responsavel}\n"
            
            # We need to manually update observations since form only updates responsavel_prejuizo
            # But wait, form.save() saves the instance. If we modify instance before save, it works.
            avaria = form.save(commit=False)
            
            if avaria.observacoes:
                avaria.observacoes += "\n" + new_entry
            else:
                avaria.observacoes = new_entry
            
            avaria.save()
            messages.success(request, f'Responsabilidade definida para Avaria #{avaria.id}')
            return redirect('avaria_definicao_prejuizo_list')
    
    return render(request, 'app_avarias/avaria_prejuizo_list.html', {'avarias': qs})

@login_required
def avaria_print(request, pk):
    avaria = get_object_or_404(Avaria, pk=pk)
    show_photos = request.GET.get('fotos') == '1'
    
    fotos = []
    if show_photos:
        fotos = avaria.fotos.all().order_by('criado_por', '-data_upload')
        
    context = {
        'avaria': avaria,
        'show_photos': show_photos,
        'fotos': fotos
    }
    return render(request, 'app_avarias/avaria_print.html', context)
