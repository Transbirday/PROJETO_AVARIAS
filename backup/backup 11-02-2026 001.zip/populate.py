
import os
import django
import random
from decimal import Decimal
from datetime import timedelta
from django.utils import timezone
import string

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from app_avarias.models import Usuario, Cliente, Condutor, Veiculo, Produto, Avaria, AvariaItem

def create_vehicles():
    print("Creating Vehicles...")
    types = [
        ('FROTA', 'PRINCIPAL', None, None),
        ('AGREGADO', 'PRINCIPAL', None, None),
        ('TERCEIRO', 'PRINCIPAL', 'TRANSPORTADORA TESTE A', '12.345.678/0001-90'),
        ('TERCEIRO', 'PRINCIPAL', 'LOGISTICA EXPRESS', '98.765.432/0001-10'),
    ]
    
    vehicles = []
    headers = ['FRT', 'AGR', 'TRC', 'TRD']
    
    for i in range(5):
        for idx, (prop, tipo, transp_nome, transp_cnpj) in enumerate(types):
            placa = f"{headers[idx]}{random.randint(1000,9999)}"
            v, created = Veiculo.objects.get_or_create(
                placa=placa,
                defaults={
                    'tipo': tipo,
                    'propriedade': prop,
                    'modelo': f"Caminhão Teste {prop}",
                    'transportadora_nome': transp_nome,
                    'transportadora_cnpj': transp_cnpj
                }
            )
            vehicles.append(v)
    return vehicles

def create_drivers():
    print("Creating Drivers...")
    drivers = []
    for i in range(10):
        cpf = f"{random.randint(100,999)}.{random.randint(100,999)}.{random.randint(100,999)}-{random.randint(10,99)}"
        d, created = Condutor.objects.get_or_create(
            cpf=cpf,
            defaults={'nome': f"Motorista Teste {i+1}"}
        )
        drivers.append(d)
    return drivers

def random_date(start, end):
    delta = end - start
    int_delta = (delta.days * 24 * 60 * 60) + delta.seconds
    random_second = random.randrange(int_delta)
    return start + timedelta(seconds=random_second)

def populate_avarias(n=300):
    print(f"Generating {n} Avarias...")
    
    users = list(Usuario.objects.all())
    clientes = list(Cliente.objects.all())
    produtos = list(Produto.objects.all())
    
    if not users or not clientes or not produtos:
        print("Error: Ensure Users, Clients and Products exist.")
        return

    vehicles = create_vehicles()
    drivers = create_drivers()
    
    end_date = timezone.now()
    start_date = end_date - timedelta(days=5*365)
    
    states = ['SP - São Paulo', 'RJ - Rio de Janeiro', 'MG - Minas Gerais', 'PR - Paraná', 'SC - Santa Catarina', 'RS - Rio Grande do Sul', 'BA - Bahia', 'GO - Goiás']
    
    created_count = 0
    
    for _ in range(n):
        # Base Creation
        dt_criacao = random_date(start_date, end_date)
        user = random.choice(users)
        client = random.choice(clientes)
        driver = random.choice(drivers)
        vehicle = random.choice(vehicles)
        
        avaria = Avaria(
            cliente=client,
            nota_fiscal=f"{random.randint(10000, 99999)}",
            motorista=driver,
            veiculo=vehicle,
            criado_por=user,
            data_criacao=dt_criacao,
            local_atuacao=random.choice(states),
            observacoes="Gerado automaticamente pelo script de população.",
            status='EM_ABERTO'
        )
        
        # Decide Fate
        # Weights: 10% Open, 10% Waiting Return, 80% Finalized
        fate = random.choices(['OPEN', 'WAITING', 'FINALIZED'], weights=[10, 10, 80])[0]
        
        if fate == 'OPEN':
            avaria.status = 'EM_ABERTO'
            
        elif fate == 'WAITING':
            dt_decision = dt_criacao + timedelta(days=random.randint(1, 5))
            if dt_decision > end_date: dt_decision = end_date
            
            avaria.data_decisao = dt_decision
            avaria.status = 'AGUARDANDO_DEVOLUCAO'
            
        elif fate == 'FINALIZED':
            dt_decision = dt_criacao + timedelta(days=random.randint(1, 3))
            
            # Sub-fate: Accepted vs Returned
            final_type = random.choices(['ACEITE', 'DEVOLUCAO_CONCLUIDA'], weights=[60, 40])[0]
            avaria.tipo_finalizacao = final_type
            avaria.data_decisao = dt_decision
            
            if final_type == 'ACEITE':
                # Financial Responsibility
                resp = random.choices(['TRANSBIRDAY', 'CLIENTE', 'TRANSPORTADORA_TERCEIRA'], weights=[20, 30, 50])[0]
                avaria.responsavel_prejuizo = resp
                avaria.valor_nf = Decimal(random.uniform(50, 5000)).quantize(Decimal('0.01'))
                avaria.data_finalizacao = dt_decision # Instant finalization on acceptance
                avaria.status = 'FINALIZADA'
                
            else: # DEVOLUCAO_CONCLUIDA
                dt_start_return = dt_decision + timedelta(days=random.randint(1, 5))
                dt_end_return = dt_start_return + timedelta(days=random.randint(2, 10))
                
                if dt_end_return > end_date:
                    avaria.status = 'EM_ROTA_DEVOLUCAO'
                    avaria.data_inicio_devolucao = dt_start_return
                else:
                    avaria.status = 'FINALIZADA'
                    avaria.data_inicio_devolucao = dt_start_return
                    avaria.data_finalizacao = dt_end_return
                    # Usually no financial loss here for dashboard unless we track logistics cost, but strict req says loss lists
                    # Loss only creates if Accepted usually? Or valid loss?
                    # "Prejuízo" implies someone pays. If returned, usually no "prejudice" on product value, maybe freight.
                    # Prompt says: "finalizados, aceitos, devolvidos, prejuízo da Transbirday..."
                    # I'll assume only Accepted has monetary loss value filled in `valor_nf` contextually for the dashboard tables.
        
        avaria.save()
        
        # Add Items
        num_items = random.randint(1, 5)
        chosen_products = random.sample(produtos, min(len(produtos), num_items))
        
        for p in chosen_products:
            AvariaItem.objects.create(
                avaria=avaria,
                produto=p,
                quantidade=random.randint(1, 10),
                lote=f"L{random.randint(100,999)}"
            )
            
        created_count += 1

    print(f"Successfully created {created_count} Avarias.")

if __name__ == '__main__':
    populate_avarias(350)
